package com.example.infoplus;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
public class Nothing extends Activity {
	private WebView web;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.info);
		web = (WebView) findViewById(R.id.webview);
		WebSettings configurarWebView = web.getSettings();
		configurarWebView.setJavaScriptEnabled(true);
		configurarWebView.setSupportMultipleWindows(true);
		configurarWebView.setSupportZoom(false);
		web.setVerticalScrollBarEnabled(true);
		web.setHorizontalScrollBarEnabled(true);
		web.loadUrl("file:///android_asset/informacoes/informacoes.html");
	}
}