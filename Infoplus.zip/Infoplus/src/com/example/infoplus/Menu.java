package com.example.infoplus;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
public class Menu extends Activity implements OnClickListener {
	Button bt1, bt2, bt3, bt4;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);
		bt1 = (Button) findViewById(R.id.btx);
		bt1.setOnClickListener(this);
		bt2 = (Button) findViewById(R.id.bty);
		bt2.setOnClickListener(this);
		bt3 = (Button) findViewById(R.id.btz);
		bt3.setOnClickListener(this);
		bt4 = (Button) findViewById(R.id.btw);
		bt4.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btx:
			Intent intent = new Intent(this, Nothing.class);
			startActivity(intent);
			break;
		case R.id.bty:
			Intent intent1 = new Intent(this, Nothing.class);
			startActivity(intent1);
			break;
		case R.id.btz:
			Intent intent2 = new Intent(this, Nothing.class);
			startActivity(intent2);
			break;
		case R.id.btw:
			Intent intent3 = new Intent(this, Nothing.class);
			startActivity(intent3);
			break;
		}
	}
}